import { useState, useRef, useEffect } from "react";

// ─── IMPORTANT: Replace with your Anthropic API Key ───────────────────────
// Get your key from https://console.anthropic.com
const API_KEY = "YOUR_ANTHROPIC_API_KEY_HERE";

// ─── In-Memory User Store (Replace with Supabase for production) ──────────
const userStore = {};

// ─── AI Modes ─────────────────────────────────────────────────────────────
const MODES = [
  {
    id: "analyze", icon: "📊", label: "Data Analysis", color: "#3b82f6",
    gradient: "linear-gradient(135deg,#1d4ed8,#3b82f6)",
    placeholder: "Paste your financial data here...\n\nExample: Revenue Q1:₹12L, Q2:₹18L, Q3:₹15L, Q4:₹22L. Analyze trends and give insights.",
    system: `You are a senior financial analyst AI for a Finance & Accounting team in India.
Analyze financial data and always respond with these sections:
📈 **Trend Analysis**
🔢 **Key Metrics**
💡 **Insights**
⚠️ **Risk Flags**
✅ **Recommendations**
Use ₹, Lakhs, Crores. Be specific, data-driven, and professional.`
  },
  {
    id: "email", icon: "✉️", label: "Email Drafting", color: "#10b981",
    gradient: "linear-gradient(135deg,#047857,#10b981)",
    placeholder: "Describe the email you need...\n\nExample: Write a payment reminder for client who has overdue invoice of ₹2.5L for 30 days.",
    system: `You are a professional business communication expert for a Finance & Accounting firm in India.
Always format as:
📧 **Subject:** [subject line]

[Full professional email body]

---
💡 **Tone Note:** [brief note on tone]
💬 **Alternative Subject:** [one alternative]`
  },
  {
    id: "report", icon: "📋", label: "Report Writing", color: "#f59e0b",
    gradient: "linear-gradient(135deg,#b45309,#f59e0b)",
    placeholder: "Describe the report you need...\n\nExample: Monthly financial summary for Oct 2024. Revenue:₹45L, Expenses:₹32L, Net Profit:₹13L.",
    system: `You are a senior financial report writer for a Finance & Accounting team in India.
Create professional structured reports with:
- Executive Summary
- Key Financial Highlights
- Detailed Analysis
- Variance Analysis (if applicable)
- Conclusions & Next Steps
Use ₹/Lakhs/Crores. Make reports board-ready and professional.`
  },
  {
    id: "general", icon: "🤖", label: "General Assistant", color: "#8b5cf6",
    gradient: "linear-gradient(135deg,#6d28d9,#8b5cf6)",
    placeholder: "Ask any finance or business question...\n\nExample: Explain GST input tax credit rules for a manufacturing company.",
    system: `You are an expert Business AI assistant for Finance & Accounting in India.
You have deep knowledge of GST, Income Tax, TDS, IndAS, GAAP, cash flow, compliance, and business strategy.
Give expert, accurate, practical advice. Mention if something needs a qualified CA or legal expert.`
  }
];

const QUICK_PROMPTS = {
  analyze: ["Analyze monthly P&L", "Cash flow trend analysis", "Compare quarterly revenue", "Expense breakdown insights"],
  email: ["Overdue payment reminder", "Client proposal follow-up", "Audit request to client", "Salary revision communication"],
  report: ["Monthly financial summary", "GST filing report", "Budget vs Actual report", "Year-end highlights"],
  general: ["GST input tax credit rules", "Best cash flow practices", "Invoice discounting explained", "TDS compliance checklist"],
};

// ─── Root ──────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const [screen, setScreen] = useState("login");

  if (screen !== "app" || !user) {
    return <AuthScreen screen={screen} setScreen={setScreen} setUser={setUser} />;
  }
  return <CFODeskApp user={user} onLogout={() => { setUser(null); setScreen("login"); }} />;
}

// ─── Auth Screen ───────────────────────────────────────────────────────────
function AuthScreen({ screen, setScreen, setUser }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const isLogin = screen === "login";

  const handleSubmit = () => {
    setError("");
    if (!email || !password) return setError("Please fill in all fields.");
    if (!isLogin && !name) return setError("Please enter your full name.");
    if (password.length < 6) return setError("Password must be at least 6 characters.");
    setLoading(true);
    setTimeout(() => {
      if (!isLogin) {
        if (userStore[email]) { setError("Account already exists. Please login."); setLoading(false); return; }
        userStore[email] = { name, email, password };
        setUser({ name, email });
        setScreen("app");
      } else {
        const u = userStore[email];
        if (!u || u.password !== password) { setError("Invalid email or password."); setLoading(false); return; }
        setUser({ name: u.name, email });
        setScreen("app");
      }
      setLoading(false);
    }, 800);
  };

  return (
    <div style={a.root}>
      <style>{globalCSS}</style>
      <div style={a.blob1} /><div style={a.blob2} />
      <div style={a.card}>
        <div style={a.logoArea}>
          <div style={a.logoEmoji}>💼</div>
          <div style={a.logoName}>CFODesk</div>
          <div style={a.logoTag}>AI Finance & Accounting Assistant</div>
        </div>

        <div style={a.tabs}>
          <button style={{ ...a.tab, ...(isLogin ? a.tabOn : {}) }} onClick={() => { setScreen("login"); setError(""); }}>Login</button>
          <button style={{ ...a.tab, ...(!isLogin ? a.tabOn : {}) }} onClick={() => { setScreen("signup"); setError(""); }}>Sign Up</button>
        </div>

        {!isLogin && <InputField label="Full Name" value={name} onChange={setName} placeholder="Rahul Sharma" />}
        <InputField label="Work Email" value={email} onChange={setEmail} placeholder="you@company.com" type="email" />
        <InputField label="Password" value={password} onChange={setPassword} placeholder="Min. 6 characters" type="password" />

        {error && <div style={a.errBox}>⚠️ {error}</div>}

        <button style={a.submitBtn} onClick={handleSubmit} disabled={loading}>
          {loading ? "Please wait..." : isLogin ? "Login to CFODesk →" : "Create Account →"}
        </button>

        <div style={a.switchRow}>
          {isLogin ? "Don't have an account? " : "Already registered? "}
          <span style={a.switchLink} onClick={() => { setScreen(isLogin ? "signup" : "login"); setError(""); }}>
            {isLogin ? "Sign Up Free" : "Login"}
          </span>
        </div>

        <div style={a.chips}>
          {["📊 Data Analysis", "✉️ Email Drafting", "📋 Report Writing", "🤖 AI Assistant"].map(f => (
            <span key={f} style={a.chip}>{f}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

function InputField({ label, value, onChange, placeholder, type = "text" }) {
  return (
    <div style={{ marginBottom: 15 }}>
      <label style={a.label}>{label}</label>
      <input style={a.input} type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} />
    </div>
  );
}

// ─── Main App ──────────────────────────────────────────────────────────────
function CFODeskApp({ user, onLogout }) {
  const [activeMode, setActiveMode] = useState("analyze");
  const [sessions, setSessions] = useState({ analyze: [], email: [], report: [], general: [] });
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const bottomRef = useRef(null);
  const mode = MODES.find(m => m.id === activeMode);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [sessions, activeMode]);

  const send = async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput(""); setLoading(true);
    setSessions(prev => ({ ...prev, [activeMode]: [...prev[activeMode], { role: "user", content: msg }] }));
    const history = sessions[activeMode].map(m => ({ role: m.role, content: m.content }));
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1024,
          system: mode.system,
          messages: [...history, { role: "user", content: msg }],
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "Sorry, I couldn't get a response. Please try again.";
      setSessions(prev => ({ ...prev, [activeMode]: [...prev[activeMode], { role: "assistant", content: reply }] }));
    } catch {
      setSessions(prev => ({ ...prev, [activeMode]: [...prev[activeMode], { role: "assistant", content: "⚠️ Network error. Please check your connection and try again." }] }));
    }
    setLoading(false);
  };

  const initials = user.name ? user.name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) : user.email[0].toUpperCase();
  const msgs = sessions[activeMode];

  return (
    <div style={s.root}>
      <style>{globalCSS}</style>

      {/* Sidebar */}
      {sidebarOpen && (
        <aside style={s.sidebar}>
          <div style={s.sideHead}>
            <span style={{ fontSize: 26 }}>💼</span>
            <div>
              <div style={s.sideTitle}>CFODesk</div>
              <div style={s.sideSub}>Finance AI Assistant</div>
            </div>
          </div>

          <div style={s.secLabel}>MODULES</div>
          {MODES.map(m => (
            <button key={m.id} className="mbtn" onClick={() => setActiveMode(m.id)} style={{
              ...s.modeBtn,
              background: activeMode === m.id ? "rgba(255,255,255,0.07)" : "transparent",
              borderLeft: activeMode === m.id ? `3px solid ${m.color}` : "3px solid transparent",
            }}>
              <span style={{ fontSize: 17 }}>{m.icon}</span>
              <span style={{ fontSize: 13, fontWeight: 500, flex: 1, color: activeMode === m.id ? "#f1f5f9" : "#94a3b8" }}>{m.label}</span>
              {sessions[m.id].length > 0 && (
                <span style={{ ...s.badge, background: m.color }}>{Math.ceil(sessions[m.id].length / 2)}</span>
              )}
            </button>
          ))}

          <div style={{ marginTop: "auto", padding: 14 }}>
            <div style={s.userCard}>
              <div style={s.uAvatar}>{initials}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={s.uName}>{user.name || "User"}</div>
                <div style={s.uEmail}>{user.email}</div>
              </div>
              <button style={s.logoutBtn} onClick={onLogout} title="Logout">⏻</button>
            </div>
          </div>
        </aside>
      )}

      {/* Main */}
      <div style={s.main}>
        {/* Topbar */}
        <header style={s.topbar}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button style={s.menuBtn} onClick={() => setSidebarOpen(p => !p)}>☰</button>
            <div style={{ ...s.modeTag, background: `${mode.color}18`, border: `1px solid ${mode.color}33` }}>
              <span>{mode.icon}</span>
              <span style={{ color: mode.color, fontWeight: 600, fontSize: 13 }}>{mode.label}</span>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {msgs.length > 0 && (
              <button style={s.clearBtn} onClick={() => setSessions(p => ({ ...p, [activeMode]: [] }))}>🗑 Clear</button>
            )}
            <div style={s.topAvatar}>{initials}</div>
          </div>
        </header>

        {/* Chat */}
        <div style={s.chat}>
          {msgs.length === 0 ? (
            <div style={s.empty}>
              <div style={{ fontSize: 52, marginBottom: 14 }}>{mode.icon}</div>
              <h2 style={s.emptyTitle}>{mode.label}</h2>
              <p style={s.emptyDesc}>
                {activeMode === "analyze" && "Paste your financial data and get instant analysis, trends & actionable insights."}
                {activeMode === "email" && "Describe the email you need and get a polished professional draft instantly."}
                {activeMode === "report" && "Provide your data and get a board-ready structured financial report."}
                {activeMode === "general" && "Ask any finance, accounting, GST, or business question."}
              </p>
              <div style={s.quickGrid}>
                {QUICK_PROMPTS[activeMode].map(q => (
                  <button key={q} className="qbtn" style={s.quickBtn} onClick={() => send(q)}>{q}</button>
                ))}
              </div>
            </div>
          ) : (
            msgs.map((m, i) => (
              <div key={i} className="fadeUp">
                {m.role === "user" ? (
                  <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
                    <div style={{ ...s.userBubble, background: mode.gradient }}>{m.content}</div>
                  </div>
                ) : (
                  <div style={{ display: "flex", gap: 10, marginBottom: 16, alignItems: "flex-start" }}>
                    <div style={{ ...s.aiAvatar, background: `${mode.color}18`, border: `1px solid ${mode.color}33` }}>{mode.icon}</div>
                    <div style={s.aiBubble}><MDText text={m.content} /></div>
                  </div>
                )}
              </div>
            ))
          )}

          {loading && (
            <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              <div style={{ ...s.aiAvatar, background: `${mode.color}18`, border: `1px solid ${mode.color}33` }}>{mode.icon}</div>
              <div style={{ ...s.aiBubble, display: "flex", alignItems: "center", gap: 8 }}>
                {[0, 0.15, 0.3].map((d, i) => (
                  <span key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: mode.color, display: "inline-block", animation: `pulse 1s ${d}s infinite` }} />
                ))}
                <span style={{ fontSize: 12, color: "#64748b", marginLeft: 4 }}>Analyzing...</span>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={s.inputArea}>
          <div style={{ ...s.inputBox, borderColor: `${mode.color}33` }}>
            <textarea
              style={s.textarea}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder={mode.placeholder}
              rows={3}
            />
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 10px 8px 14px" }}>
              <span style={{ fontSize: 11, color: "#334155" }}>Enter to send • Shift+Enter for new line</span>
              <button
                disabled={!input.trim() || loading}
                onClick={() => send()}
                style={{ ...s.sendBtn, background: mode.gradient, opacity: input.trim() && !loading ? 1 : 0.4, cursor: input.trim() && !loading ? "pointer" : "not-allowed" }}
              >Send ➤</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Markdown Renderer ────────────────────────────────────────────────────
function MDText({ text }) {
  return (
    <div style={{ lineHeight: 1.75, fontSize: 14 }}>
      {text.split("\n").map((line, i) => {
        if (line.startsWith("## ")) return <div key={i} style={{ fontWeight: 700, fontSize: 15, color: "#f1f5f9", marginTop: 14, marginBottom: 6 }}>{line.slice(3)}</div>;
        if (/^\*\*.*\*\*$/.test(line.trim())) return <div key={i} style={{ fontWeight: 700, color: "#e2e8f0", marginTop: 10, marginBottom: 4 }}>{line.replace(/\*\*/g, "")}</div>;
        if (line.startsWith("- ") || line.startsWith("• ")) return <div key={i} style={{ paddingLeft: 16, marginBottom: 4, color: "#cbd5e1" }}>• {line.replace(/^[-•] /, "")}</div>;
        if (line === "---") return <hr key={i} style={{ border: "none", borderTop: "1px solid rgba(255,255,255,0.07)", margin: "10px 0" }} />;
        if (line === "") return <div key={i} style={{ height: 6 }} />;
        const parts = line.split(/(\*\*[^*]+\*\*)/g);
        return <div key={i} style={{ color: "#cbd5e1", marginBottom: 2 }}>{parts.map((p, j) => p.startsWith("**") ? <strong key={j} style={{ color: "#e2e8f0" }}>{p.replace(/\*\*/g, "")}</strong> : <span key={j}>{p}</span>)}</div>;
      })}
    </div>
  );
}

// ─── Global CSS ───────────────────────────────────────────────────────────
const globalCSS = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'DM Sans', sans-serif; }
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 10px; }
  input:focus, textarea:focus { outline: none; }
  textarea { resize: none; font-family: 'DM Sans', sans-serif; }
  @keyframes fadeUp { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }
  @keyframes float { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-8px); } }
  @keyframes pulse { 0%,100% { opacity:.3; } 50% { opacity:1; } }
  .fadeUp { animation: fadeUp 0.3s ease; }
  .qbtn:hover { background: rgba(255,255,255,0.09) !important; transform: translateY(-1px); }
  .mbtn:hover { background: rgba(255,255,255,0.05) !important; }
`;

// ─── Auth Styles ──────────────────────────────────────────────────────────
const a = {
  root: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#06090f", fontFamily: "'DM Sans',sans-serif", position: "relative", overflow: "hidden", padding: 20 },
  blob1: { position: "fixed", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle,rgba(59,130,246,0.08),transparent 70%)", top: -150, left: -150, pointerEvents: "none" },
  blob2: { position: "fixed", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle,rgba(139,92,246,0.07),transparent 70%)", bottom: -150, right: -150, pointerEvents: "none" },
  card: { background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: "36px 32px", width: "100%", maxWidth: 420, position: "relative", zIndex: 1 },
  logoArea: { textAlign: "center", marginBottom: 28 },
  logoEmoji: { fontSize: 52, display: "block", marginBottom: 10, animation: "float 3s ease-in-out infinite" },
  logoName: { fontSize: 28, fontWeight: 800, color: "#fff", letterSpacing: "-1px" },
  logoTag: { fontSize: 12, color: "#64748b", marginTop: 4 },
  tabs: { display: "flex", background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: 4, marginBottom: 22, gap: 4 },
  tab: { flex: 1, padding: "9px 0", border: "none", background: "transparent", color: "#64748b", fontFamily: "'DM Sans',sans-serif", fontSize: 13, fontWeight: 600, borderRadius: 8, cursor: "pointer", transition: "all 0.2s" },
  tabOn: { background: "rgba(255,255,255,0.08)", color: "#f1f5f9" },
  label: { fontSize: 12, fontWeight: 600, color: "#64748b", marginBottom: 6, display: "block" },
  input: { width: "100%", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, padding: "11px 14px", color: "#f1f5f9", fontSize: 14, fontFamily: "'DM Sans',sans-serif" },
  errBox: { background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", color: "#f87171", fontSize: 12, padding: "10px 12px", borderRadius: 8, marginBottom: 14 },
  submitBtn: { width: "100%", background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", border: "none", color: "#fff", padding: 13, borderRadius: 10, fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'DM Sans',sans-serif", marginTop: 4 },
  switchRow: { textAlign: "center", fontSize: 13, color: "#64748b", marginTop: 18 },
  switchLink: { color: "#60a5fa", cursor: "pointer", fontWeight: 600 },
  chips: { display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", marginTop: 20 },
  chip: { fontSize: 11, color: "#475569", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", padding: "4px 10px", borderRadius: 20 },
};

// ─── App Styles ───────────────────────────────────────────────────────────
const s = {
  root: { display: "flex", height: "100vh", background: "#080c14", color: "#f1f5f9", fontFamily: "'DM Sans',sans-serif", overflow: "hidden" },
  sidebar: { width: 235, background: "#0d1117", borderRight: "1px solid rgba(255,255,255,0.06)", display: "flex", flexDirection: "column", flexShrink: 0 },
  sideHead: { display: "flex", alignItems: "center", gap: 10, padding: "18px 16px", borderBottom: "1px solid rgba(255,255,255,0.06)" },
  sideTitle: { fontWeight: 800, fontSize: 16, color: "#fff", letterSpacing: "-0.5px" },
  sideSub: { fontSize: 11, color: "#64748b", marginTop: 1 },
  secLabel: { fontSize: 10, fontWeight: 700, color: "#334155", letterSpacing: "1.5px", padding: "16px 16px 8px" },
  modeBtn: { display: "flex", alignItems: "center", gap: 10, width: "100%", padding: "11px 16px", border: "none", cursor: "pointer", transition: "all 0.2s", textAlign: "left" },
  badge: { fontSize: 10, fontWeight: 700, color: "#fff", borderRadius: 50, width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center" },
  userCard: { display: "flex", alignItems: "center", gap: 9, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 10, padding: "10px 11px" },
  uAvatar: { width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#fff", flexShrink: 0 },
  uName: { fontSize: 12, fontWeight: 600, color: "#e2e8f0", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  uEmail: { fontSize: 10, color: "#64748b", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  logoutBtn: { background: "transparent", border: "none", color: "#64748b", cursor: "pointer", fontSize: 16, flexShrink: 0 },
  main: { flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" },
  topbar: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 18px", borderBottom: "1px solid rgba(255,255,255,0.06)", background: "#0a0e18", flexShrink: 0 },
  menuBtn: { background: "transparent", border: "none", color: "#64748b", fontSize: 20, cursor: "pointer", padding: "4px 8px", borderRadius: 6 },
  modeTag: { display: "flex", alignItems: "center", gap: 6, padding: "5px 12px", borderRadius: 20 },
  clearBtn: { background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", color: "#f87171", padding: "5px 11px", borderRadius: 8, cursor: "pointer", fontSize: 12, fontFamily: "inherit" },
  topAvatar: { width: 30, height: 30, borderRadius: "50%", background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#fff" },
  chat: { flex: 1, overflowY: "auto", padding: "20px 18px", display: "flex", flexDirection: "column", gap: 4 },
  empty: { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "40px 20px", marginTop: 30 },
  emptyTitle: { fontSize: 22, fontWeight: 700, color: "#fff", marginBottom: 10 },
  emptyDesc: { fontSize: 14, color: "#64748b", maxWidth: 400, lineHeight: 1.7, marginBottom: 24 },
  quickGrid: { display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", maxWidth: 480 },
  quickBtn: { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.09)", color: "#94a3b8", padding: "9px 15px", borderRadius: 20, cursor: "pointer", fontSize: 12, fontWeight: 500, transition: "all 0.2s", fontFamily: "inherit" },
  userBubble: { maxWidth: "70%", padding: "12px 16px", borderRadius: "16px 16px 4px 16px", fontSize: 14, lineHeight: 1.65, fontWeight: 500, color: "#fff" },
  aiAvatar: { width: 34, height: 34, borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, flexShrink: 0, marginTop: 2 },
  aiBubble: { flex: 1, maxWidth: "calc(100% - 44px)", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", padding: "13px 15px", borderRadius: "4px 16px 16px 16px" },
  inputArea: { padding: "12px 18px 16px", flexShrink: 0, background: "#0a0e18", borderTop: "1px solid rgba(255,255,255,0.06)" },
  inputBox: { background: "rgba(255,255,255,0.04)", border: "1px solid", borderRadius: 12, overflow: "hidden" },
  textarea: { width: "100%", background: "transparent", border: "none", color: "#f1f5f9", fontSize: 14, padding: "13px 15px 6px", lineHeight: 1.6 },
  sendBtn: { border: "none", color: "#fff", padding: "8px 17px", borderRadius: 8, fontSize: 13, fontWeight: 600, fontFamily: "inherit", transition: "all 0.2s" },
};
