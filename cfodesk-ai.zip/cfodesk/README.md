# 💼 CFODesk — AI Finance & Accounting Assistant

CFODesk is a powerful AI-powered Finance & Accounting assistant built for teams. It helps with Data Analysis, Email Drafting, Report Writing, and general Finance queries.

---

## ✨ Features

- 📊 **Data Analysis** — Analyze P&L, revenue, cash flow trends
- ✉️ **Email Drafting** — Professional finance emails in seconds
- 📋 **Report Writing** — Board-ready financial reports instantly
- 🤖 **General Assistant** — GST, TDS, IndAS, compliance queries
- 🔐 **Login System** — Email & password authentication
- 👥 **Team Ready** — Share with your entire team

---

## 🚀 Setup & Deploy

### Step 1 — Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/cfodesk-ai.git
cd cfodesk-ai
```

### Step 2 — Install dependencies
```bash
npm install
```

### Step 3 — Add your API Key
Open `src/App.jsx` and replace:
```js
const API_KEY = "YOUR_ANTHROPIC_API_KEY_HERE";
```
With your actual key from: https://console.anthropic.com

### Step 4 — Run locally
```bash
npm run dev
```
Open http://localhost:5173

### Step 5 — Deploy on Vercel
- Go to https://vercel.com
- Click **"Import Git Repository"**
- Select `cfodesk-ai`
- Click **Deploy** 🚀

---

## 🌐 Connect Custom Domain (cfodesk.in)
After deploying on Vercel:
1. Go to Project Settings → Domains
2. Add `cfodesk.in`
3. Update DNS records at your domain registrar

---

## 🔑 Get Anthropic API Key
1. Go to https://console.anthropic.com
2. Sign up / Login
3. Click **"API Keys"** → **"Create Key"**
4. Copy and paste into `src/App.jsx`

---

## 📁 Project Structure
```
cfodesk-ai/
├── index.html
├── package.json
├── vite.config.js
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx
    └── App.jsx        ← Main application file
```

---

## 🛠 Tech Stack
- **React 18** — Frontend framework
- **Vite** — Build tool
- **Claude API** — AI engine (Anthropic)
- **Vercel** — Hosting & deployment

---

## 📞 Support
Built with ❤️ for Finance teams in India.
